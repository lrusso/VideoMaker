Slides created with https://lrusso.github.io/bannerGenerator/bannerVideo_03_GitHub.htm

More info at https://github.com/lrusso/bannerGenerator